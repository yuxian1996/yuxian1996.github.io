Press W/A/S/D to move the rectangle.
Hold Control and press W/A/S/D to move the triangle. 
Press Up/Down/Left/Right Arrow to move camera.