#pragma once

#include <Engine/Results/Results.h>
#include <Engine/Logging/Logging.h>

#include <cinttypes>
#include <cstdlib>
#include <unordered_map>
#include <string>
#include <vector>

namespace eae6320
{
	namespace AI
	{
		/* Template class which stores class type and name, bool, int, float, Math::sVector, uintptr_t are supported*/
		template<class T>
		struct sBlackboardSelector
		{
			std::string mName;

			sBlackboardSelector() : mName("") {}
			sBlackboardSelector(const std::string& inName) : mName(inName) {}

			/* Convert sBlackboardSelector to std::string of typename and name*/
			std::string ToString() const { return std::string(typeid(T).name()) + "_" + mName; }
		};

		/* Store values for behavior tree and its nodes*/
		class cBlackboard
		{
		public:
			cBlackboard(uint16_t inMaxSize = 200);
			~cBlackboard();

			/* Get value of sBlackboardSelector<T>*/
			template<class T>
			T GetValue(const sBlackboardSelector<T>& inSelector); 

			/* Set value of sBlackboardSelector<T> by input value*/
			template<class T>
			void SetValue(const sBlackboardSelector<T>& inSelector, const T& inValue);

			/* Add new key by sBlackboardSelector<T>.
			Failed if there's not enough memory to store a new key.
			All the bytes stored are 0x00*/
			template<class T>
			bool AddKey(const sBlackboardSelector<T> inSelector);

			/* Load blackboard file and output blackboard object*/
			static eae6320::cResult Load(const char* ipPath, cBlackboard*& outBlackboard);

		private:
			uint16_t mMaxSize;
			uint16_t mSize;
			void* mData;

			std::unordered_map<std::string, uint16_t> mMap;
			
		};


		template<class T>
		inline T cBlackboard::GetValue(const sBlackboardSelector<T>& inSelector)
		{
			std::string key = inSelector.ToString();
			if (mMap.find(key) == mMap.end())
				return T();

			return *reinterpret_cast<T*>(reinterpret_cast<intptr_t>(mData) + mMap[key]);
		}

		template<class T>
		inline void cBlackboard::SetValue(const sBlackboardSelector<T>& inSelector, const T & inValue)
		{
			std::string key = inSelector.ToString();
			if (mMap.find(key) == mMap.end())
				return;

			*reinterpret_cast<T*>(reinterpret_cast<intptr_t>(mData) + mMap[key]) = inValue;

		}

		template<class T>
		inline bool cBlackboard::AddKey(const sBlackboardSelector<T> inSelector)
		{
			uint16_t size = static_cast<uint16_t>(sizeof(T));

			if (mSize + size <= mMaxSize)
			{
				// convert sBlackboardSelector to string then store the map of string and offset;
				mMap[inSelector.ToString()] = mSize;
				mSize += size;
				return true;
			}

			return false;
		}
	}
}