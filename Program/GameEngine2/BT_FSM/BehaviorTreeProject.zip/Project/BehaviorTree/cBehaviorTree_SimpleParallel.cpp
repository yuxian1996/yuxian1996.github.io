#include "cBehaviorTree_SimpleParallel.h"

#include "cBehaviorTree_Task.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_SimpleParallel::cBehaviorTree_SimpleParallel()
	{
	}
	cBehaviorTree_SimpleParallel::~cBehaviorTree_SimpleParallel()
	{
	}

	bool cBehaviorTree_SimpleParallel::Execute() const
	{
		if (!CheckDecorator())
			return false;

		mpMainTask->Execute();
		mChildren[0]->Execute();

		return true;
	}
	void cBehaviorTree_SimpleParallel::Cleanup()
	{
		cBehaviorTree_Composite::Cleanup();
		if (mpMainTask != nullptr)
			delete mpMainTask;

		mpMainTask = nullptr;
	}
	void cBehaviorTree_SimpleParallel::SetMainTask(cBehaviorTree_Task * ipTask)
	{
		mpMainTask = ipTask;
	}
}
}