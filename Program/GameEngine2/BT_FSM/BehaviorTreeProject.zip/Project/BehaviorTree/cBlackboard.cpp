#include "cBlackboard.h"

#include <Engine/Math/sVector.h>
#include <Engine/Asserts/Asserts.h>
#include <Engine/Platform/Platform.h>

namespace eae6320
{
namespace AI
{
	cBlackboard::cBlackboard(uint16_t inMaxSize) : mMaxSize(inMaxSize), mSize(0)
	{
		mData = malloc(mMaxSize);
		memset(mData, 0, inMaxSize);
	}

	cBlackboard::~cBlackboard()
	{
		free(mData);
	}

	eae6320::cResult cBlackboard::Load(const char * ipPath, cBlackboard *& outBlackboard)
	{

		auto result = eae6320::Results::Success;

		Platform::sDataFromFile dataFromFile;
		std::string errorMessage;
		outBlackboard = new cBlackboard();
		if (!(result = Platform::LoadBinaryFile(ipPath, dataFromFile, &errorMessage)))
		{
			EAE6320_ASSERTF(false, "Load blackboard file failed: %s", errorMessage.c_str());
			goto OnExit;
		}

		// load links
		{
			// bool
			uintptr_t currentOffset = reinterpret_cast<uintptr_t>(dataFromFile.data);
			uint16_t count = *reinterpret_cast<uint16_t*>(currentOffset);
			currentOffset += sizeof(count);

			for (uint16_t i = 0; i < count; i++)
			{
				uint8_t length = *reinterpret_cast<uint8_t*>(currentOffset);
				currentOffset += sizeof(length);
				if (!outBlackboard->AddKey(sBlackboardSelector<bool>(reinterpret_cast<const char*>(currentOffset))))
				{
					result = eae6320::Results::OutOfMemory;
					goto OnExit;
				}
				currentOffset += length;
			}

			// int
			count = *reinterpret_cast<uint16_t*>(currentOffset);
			currentOffset += sizeof(count);
			for (uint16_t i = 0; i < count; i++)
			{
				uint8_t length = *reinterpret_cast<uint8_t*>(currentOffset);
				currentOffset += sizeof(length);
				if (!outBlackboard->AddKey(sBlackboardSelector<int>(reinterpret_cast<const char*>(currentOffset))))
				{
					result = eae6320::Results::OutOfMemory;
					goto OnExit;
				}
				currentOffset += length;
			}

			// float
			count = *reinterpret_cast<uint16_t*>(currentOffset);
			currentOffset += sizeof(count);
			for (uint16_t i = 0; i < count; i++)
			{
				uint8_t length = *reinterpret_cast<uint8_t*>(currentOffset);
				currentOffset += sizeof(length);
				if (!outBlackboard->AddKey(sBlackboardSelector<float>(reinterpret_cast<const char*>(currentOffset))))
				{
					result = eae6320::Results::OutOfMemory;
					goto OnExit;
				}
				currentOffset += length;
			}

			// vector
			count = *reinterpret_cast<uint16_t*>(currentOffset);
			currentOffset += sizeof(count);
			for (uint16_t i = 0; i < count; i++)
			{
				uint8_t length = *reinterpret_cast<uint8_t*>(currentOffset);
				currentOffset += sizeof(length);
				if (!outBlackboard->AddKey(sBlackboardSelector<Math::sVector>(reinterpret_cast<const char*>(currentOffset))))
				{
					result = eae6320::Results::OutOfMemory;
					goto OnExit;
				}
				currentOffset += length;
			}

			// pointer
			count = *reinterpret_cast<uint16_t*>(currentOffset);
			currentOffset += sizeof(count);
			for (uint16_t i = 0; i < count; i++)
			{
				uint8_t length = *reinterpret_cast<uint8_t*>(currentOffset);
				currentOffset += sizeof(length);
				outBlackboard->AddKey(sBlackboardSelector<uintptr_t>(reinterpret_cast<const char*>(currentOffset)));
				currentOffset += length;
			}
		}

	OnExit:
		if (result != eae6320::Results::Success)
		{
			EAE6320_ASSERTF(false, "Load blackboard file failed");
			delete outBlackboard;
			outBlackboard = nullptr;
		}

		dataFromFile.Free();

		return result;
	}
}
}
