#pragma once

#include "cBehaviorTree.h"

#include <vector>

namespace eae6320
{
	namespace AI
	{
		class cBehaviorTree_Task;
		class cBehaviorTree_Decorator;
		class cBehaviorTree_Composite;
		class cBehaviorTree_Service;

		/* cBehaviorTreeNode is base node class, it can have multiple decorators and multiple services attached.*/
		class cBehaviorTreeNode
		{
		public:
			cBehaviorTreeNode();
			virtual  ~cBehaviorTreeNode();
			virtual bool Execute() const = 0;

			void AddDecorator(cBehaviorTree_Decorator* ipDecorator);
			void AddService(cBehaviorTree_Service* ipService);
			void SetTree(cBehaviorTree* ipTree) { mpTree = ipTree; }
			cBehaviorTree* GetTree() { return mpTree; }
			virtual  void Cleanup();

			void SetMustPassAllDecorator(bool isTrue) { mMustPassAllDecorator = isTrue; }

		protected:
			bool CheckDecorator() const;

			bool mMustPassAllDecorator;			// If true, the node successes only when all the decorator passes.
			std::vector<cBehaviorTree_Decorator*> mpDecorators;
			std::vector<cBehaviorTree_Service*> mpServices;
			cBehaviorTree* mpTree;
		};
	}
}