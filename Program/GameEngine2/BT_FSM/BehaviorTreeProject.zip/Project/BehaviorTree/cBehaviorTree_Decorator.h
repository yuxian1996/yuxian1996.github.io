#pragma once

#include "cBehaviorTree.h"

namespace eae6320
{
	namespace AI
	{
		/* Decorator is used to check if the node it attached to can be executed.*/
		class cBehaviorTree_Decorator
		{
		public:
			cBehaviorTree_Decorator();
			virtual ~cBehaviorTree_Decorator();

			/* Check if node can be executed*/
			virtual bool Check() const = 0;
			void SetNode(cBehaviorTreeNode* ipNode) { mpNode = ipNode; }

		protected:
			cBehaviorTreeNode* mpNode;
		};
	}
}