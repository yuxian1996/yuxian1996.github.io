#include "cBehaviorTree_Service.h"
#include "cBehaviorTreeNode.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Service::cBehaviorTree_Service()
	{
	}
	cBehaviorTree_Service::~cBehaviorTree_Service()
	{
	}
	void cBehaviorTree_Service::Run()
	{
		if (mTime <= 0)
		{
			mTime = mInterval;
			Execute();
		}
		else
			mTime -= mpNode->GetTree()->GetDeltaTime();

	}
}
}