#pragma once

#include "cBehaviorTreeNode.h"
#include "cBehaviorTree.h"

namespace eae6320
{
	namespace AI
	{
		/* Execute a task*/
		class cBehaviorTree_Task : public cBehaviorTreeNode
		{
		public:
			cBehaviorTree_Task();
			virtual ~cBehaviorTree_Task() override;

			/* Check and execute task*/
			bool Execute() const override;
			/* Execute the real task logic*/
			virtual void ExcuteTask() const = 0;

		};
	}
}