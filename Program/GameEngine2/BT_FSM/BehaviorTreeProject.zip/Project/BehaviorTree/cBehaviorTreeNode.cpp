#include "cBehaviorTreeNode.h"
#include "cBehaviorTree_Task.h"
#include "cBehaviorTree_Decorator.h"
#include "cBehaviorTree_Service.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTreeNode::cBehaviorTreeNode()
		: mMustPassAllDecorator(false), mpDecorators(std::vector<cBehaviorTree_Decorator*>())
	{
	}

	cBehaviorTreeNode::~cBehaviorTreeNode()
	{
	}

	void cBehaviorTreeNode::AddDecorator(cBehaviorTree_Decorator * inDecorator)
	{
		mpDecorators.push_back(inDecorator);
		inDecorator->SetNode(this);
	}

	void cBehaviorTreeNode::AddService(cBehaviorTree_Service * ipService)
	{
		mpServices.push_back(ipService);
		ipService->SetNode(this);
	}

	void cBehaviorTreeNode::Cleanup()
	{
	}

	bool cBehaviorTreeNode::CheckDecorator() const
	{
		if (mpDecorators.size() == 0)
		{
			for (auto* service : mpServices)
				service->Run();
			return true;
		}

		if (mMustPassAllDecorator)
		{
			for (auto decorator : mpDecorators)
			{
				if (!decorator->Check())
					return false;
			}
			for (auto* service : mpServices)
				service->Run();
			return true;
		}
		else
		{
			for (auto& decorator : mpDecorators)
			{
				if (decorator->Check())
				{
					for (auto* service : mpServices)
						service->Run();
					return true;
				}
			}
			return false;
		}
	}

}
}