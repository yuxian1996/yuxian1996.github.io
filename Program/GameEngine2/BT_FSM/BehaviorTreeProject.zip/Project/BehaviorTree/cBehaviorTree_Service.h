#pragma once

#include "cBehaviorTree.h"

namespace eae6320
{
	namespace AI
	{
		/* Service is used to run some logic by every mInterval seconds if the node it attached to successes.
		It's usually used to change blackboard values.*/
		class cBehaviorTree_Service
		{
		public:
			cBehaviorTree_Service();
			cBehaviorTree_Service(float inInterval) : mInterval(inInterval) {};
			virtual ~cBehaviorTree_Service();

			/* Run service to calculate time to execute*/
			void Run();
			/* Execute real logic*/
			virtual void Execute() = 0;
			/* Change service interval*/
			void SetInterval(float inInterval) { mInterval = inInterval; }
			/* Get service interval*/
			float GetInterval() { return mInterval; }
			/* Set the node it attached to*/
			void SetNode(cBehaviorTreeNode* ipNode) { mpNode = ipNode; }

		protected:
			float mInterval = 0;
			float mTime;
			cBehaviorTreeNode* mpNode;
		};
	}
}