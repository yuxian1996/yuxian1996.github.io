#include "cBehaviorTree_Task.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Task::cBehaviorTree_Task()
	{
	}
	cBehaviorTree_Task::~cBehaviorTree_Task()
	{
	}

	bool cBehaviorTree_Task::Execute() const
	{
		if (CheckDecorator())
		{
			ExcuteTask();
			return true;
		}

		return false;
	}
}
}