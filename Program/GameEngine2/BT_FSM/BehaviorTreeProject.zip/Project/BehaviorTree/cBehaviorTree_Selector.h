#pragma once

#include "cBehaviorTree_Composite.h"


namespace eae6320
{
	namespace AI
	{
		/* Execute from the first child to the last child. 
			Stop execute subsequent children if one child successes.
			If one child successes, it successes.*/
		class cBehaviorTree_Selector : public cBehaviorTree_Composite
		{
		public:
			cBehaviorTree_Selector();
			~cBehaviorTree_Selector();

			virtual bool Execute() const override;
		};
	}
}