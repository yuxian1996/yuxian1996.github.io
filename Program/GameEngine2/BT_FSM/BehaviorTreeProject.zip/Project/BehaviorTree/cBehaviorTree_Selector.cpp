#include "cBehaviorTree_Selector.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Selector::cBehaviorTree_Selector()
	{
	}
	cBehaviorTree_Selector::~cBehaviorTree_Selector()
	{
	}

	bool cBehaviorTree_Selector::Execute() const
	{
		if (!CheckDecorator())
			return false;

		for(auto child : mChildren)
		{
			if(child->Execute())
				return true;
		}

		return false;
	}
}
}