#pragma once

#include "cBehaviorTree_Composite.h"

namespace eae6320
{
	namespace AI
	{
		/* Execute from the first child to the last child.
		Stop execute subsequent children if one child fails.
		If one child fails, it fails.*/
		class cBehaviorTree_Sequence : public cBehaviorTree_Composite
		{
		public:
			cBehaviorTree_Sequence();
			virtual ~cBehaviorTree_Sequence();

			virtual bool Execute() const override;

		};

	}
}