#include "cBehaviorTree_Sequence.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Sequence::cBehaviorTree_Sequence()
	{
	}

	cBehaviorTree_Sequence::~cBehaviorTree_Sequence()
	{
	}

	bool cBehaviorTree_Sequence::Execute() const
	{
		if (!CheckDecorator())
			return false;

		for (auto child : mChildren)
		{
			if (!child->Execute())
				return false;
		}
		return true;
	}

}
}
