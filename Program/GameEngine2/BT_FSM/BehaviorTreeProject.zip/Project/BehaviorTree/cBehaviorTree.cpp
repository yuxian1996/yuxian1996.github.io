#include "cBehaviorTree.h"

#include "cBehaviorTreeNode.h"
#include "cBehaviorTree_Composite.h"
#include "cBehaviorTree_Task.h"
#include "cBlackboard.h"

#include <Engine/Platform/Platform.h>
#include <Engine/Asserts/Asserts.h>
#include <Engine/Results/cResult.h>

#include <vector>

namespace eae6320
{
namespace AI
{

	cBehaviorTree::cBehaviorTree(Framework::cGameObject* ipOwner, cBlackboard* ipBlackboard)
		: mpOwner(ipOwner), mpBlackboard(ipBlackboard)
	{
	}

	cBehaviorTree::~cBehaviorTree()
	{
	}

	void cBehaviorTree::Execute(float inDeltaTime)
	{
		mDeltaTime = inDeltaTime;
		if (mpRoot != nullptr)
			mpRoot->Execute();
	}

	void cBehaviorTree::Cleanup()
	{
		mpRoot->Cleanup();
		if (mpBlackboard != nullptr)
			delete mpBlackboard;
		mpBlackboard = nullptr;
	}

	void cBehaviorTree::SetRoot(cBehaviorTreeNode * ipRoot)
	{
		mpRoot = ipRoot;
		ipRoot->SetTree(this);
	}

	void cBehaviorTree::Link(std::vector<cBehaviorTreeNode*>& ipNodes, const std::vector<std::pair<uint16_t, uint16_t>>& ipLinks)
	{
		for (auto& pair : ipLinks)
		{
			if (pair.first >= 0 && pair.first < ipNodes.size() && pair.second >= 0 && pair.second < ipNodes.size())
			{
				auto composite = dynamic_cast<cBehaviorTree_Composite*>(ipNodes[pair.first]);
				if (composite != nullptr)
				{
					composite->AddChild(ipNodes[pair.second]);
				}
			}
		}
	}

	eae6320::cResult cBehaviorTree::LoadLinks(std::vector<cBehaviorTreeNode*>& ipNodes, const char * const ipFilePath)
	{
		auto result = eae6320::Results::Success;

		Platform::sDataFromFile dataFromFile;
		std::string errorMessage;
		if (!(result = Platform::LoadBinaryFile(ipFilePath, dataFromFile, &errorMessage)))
		{
			EAE6320_ASSERTF(false, "Load behavior tree link file failed: %s", errorMessage.c_str());
			goto OnExit;
		}

		// load links
		{
			size_t count = dataFromFile.size / sizeof(uint16_t) / 2;
			size_t currentOffset = reinterpret_cast<uintptr_t>(dataFromFile.data);
			std::vector<std::pair<uint16_t, uint16_t>> links;

			for (size_t i = 0; i < count; i++)
			{
				uint16_t first = *reinterpret_cast<uint16_t*>(currentOffset);
				currentOffset += sizeof(first);
				uint16_t second = *reinterpret_cast<uint16_t*>(currentOffset);
				currentOffset += sizeof(first);
				links.push_back(std::make_pair(first, second));
			}

			Link(ipNodes, links);
		}
	OnExit:
		
		dataFromFile.Free();

		return result;
	}
}
}
