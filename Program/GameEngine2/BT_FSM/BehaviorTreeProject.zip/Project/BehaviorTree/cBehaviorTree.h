#pragma once

#include <Engine/Framework/cGameObject.h>
#include <vector>

namespace eae6320
{
	namespace Framework
	{
		class cGameObject;
	}

	namespace AI
	{
		class cBehaviorTreeNode;
		class cBlackboard;

		/* Control AI behavior*/
		class cBehaviorTree
		{
		public:
			cBehaviorTree(Framework::cGameObject* ipOwner, cBlackboard* ipBlackboard = nullptr);
			~cBehaviorTree();

			/* Execute behavior tree from root*/
			void Execute(float inDeltaTime);
			/* Set root ( the node executed first)*/
			void SetRoot(cBehaviorTreeNode* ipRoot);

			//
			cBlackboard* GetBlackboard() { return mpBlackboard; }			
			Framework::cGameObject* GetOwner() { return mpOwner; }
			void Cleanup();

			/* Get Delta Time*/
			float GetDeltaTime() { return mDeltaTime; }
			
			/* Link the input nodes by input order*/
			static void Link(std::vector<cBehaviorTreeNode*>& ipNodes, const std::vector<std::pair<uint16_t, uint16_t>>& ipLinks);
			/* Load behavior tree link file and link node together*/
			static eae6320::cResult LoadLinks(std::vector<cBehaviorTreeNode*>& ipNodes, const char* const ipFilePath);

		private:
			cBehaviorTreeNode * mpRoot;
			Framework::cGameObject* mpOwner;
			cBlackboard* mpBlackboard;
			float mDeltaTime;
		};
	}
}