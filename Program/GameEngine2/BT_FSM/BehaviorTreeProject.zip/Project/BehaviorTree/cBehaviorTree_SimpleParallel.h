#pragma once

#include "cBehaviorTree_Composite.h"

namespace eae6320
{
	namespace AI
	{
		class cBehaviorTree_Task;

		/*Simple Parallel Composites should only have one main task node and one other node, 
		If it has more than one child node, only the first one will be executed,
		it executes the main task and the child node no matter if some node fails or not.
		*/
		class cBehaviorTree_SimpleParallel : public cBehaviorTree_Composite
		{
		public:
			cBehaviorTree_SimpleParallel();
			virtual ~cBehaviorTree_SimpleParallel();

			/* Execute main task and child node*/
			virtual bool Execute() const override;
			/* Cleanup*/
			virtual void Cleanup() override;

			void SetMainTask(cBehaviorTree_Task* ipTask);
		private:
			cBehaviorTree_Task * mpMainTask;
		};
	}
}