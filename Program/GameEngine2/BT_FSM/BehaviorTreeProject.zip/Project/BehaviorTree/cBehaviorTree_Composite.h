#pragma once

#include "cBehaviorTreeNode.h"

#include <vector>

namespace eae6320
{
	namespace AI
	{
		class cBehaviorTreeNode;
		/* Composite node is used to link other nodes together and execute them by some rules. It can have multiple children nodes*/
		class cBehaviorTree_Composite : public cBehaviorTreeNode
		{
		public:
			cBehaviorTree_Composite();
			virtual ~cBehaviorTree_Composite() override;

			/* Execute composite*/
			virtual bool Execute() const override = 0  ;
			/* Add input node as a child to the end of children vector*/
			virtual void AddChild(cBehaviorTreeNode* ipChild);
			/* Cleanup*/
			virtual  void Cleanup() override;

		protected:
			std::vector<cBehaviorTreeNode*> mChildren;
		};
	}
}