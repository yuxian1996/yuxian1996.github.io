#include "cBehaviorTree_Composite.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Composite::cBehaviorTree_Composite() : mChildren(std::vector<cBehaviorTreeNode*>())
	{
	}

	cBehaviorTree_Composite::~cBehaviorTree_Composite()
	{
	}

	void cBehaviorTree_Composite::AddChild(cBehaviorTreeNode* ipChild)
	{
		mChildren.push_back(ipChild);
		ipChild->SetTree(mpTree);
	}

	void cBehaviorTree_Composite::Cleanup()
	{
		for(auto& child : mChildren)
		{
			child->Cleanup();
			delete child;
		}
	}

}
}
