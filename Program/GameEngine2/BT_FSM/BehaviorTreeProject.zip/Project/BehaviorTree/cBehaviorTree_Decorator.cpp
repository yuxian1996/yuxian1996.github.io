#include "cBehaviorTree_Decorator.h"

namespace eae6320
{
namespace AI
{
	cBehaviorTree_Decorator::cBehaviorTree_Decorator()
	{
	}
	cBehaviorTree_Decorator::~cBehaviorTree_Decorator()
	{
	}

}
}

