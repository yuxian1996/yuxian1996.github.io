#ifndef EAE6320_CBEHAVIORTREEBUILDER_H
#define EAE6320_CBEHAVIORTREEBUILDER_H

#include <Tools/AssetBuildLibrary/cbBuilder.h>

namespace eae6320
{
	namespace Assets
	{
		class cBehaviorTreeBuilder : public cbBuilder
		{
		private:

			// Build
			//------

			virtual cResult Build(const std::vector<std::string>& i_arguments) override;
			cResult BuildBehaviorTree();
			cResult BuildBlackboard();
		};
	}
}

#endif
