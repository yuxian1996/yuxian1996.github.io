
#include "cBehaviorTreeBuilder.h"
#include <Plugins/BehaviorTree/cBlackboard.h>
#include <Engine/Results/Results.h>
#include <Tools/AssetBuildLibrary/LuaHelper.h>
#include <Tools/AssetBuildLibrary/Functions.h>
#include <Engine/Math/sVector.h>

#include <vector>
#include <fstream>
#include <iostream>

eae6320::cResult eae6320::Assets::cBehaviorTreeBuilder::Build(const std::vector<std::string>& i_arguments)
{
	auto result = eae6320::Results::Success;

	std::string typeName;
	if (i_arguments.size() != 0)
	{
		if (i_arguments[0] == "BehaviorTree")
		{
			result =  BuildBehaviorTree();
		}
		else if (i_arguments[0] == "Blackboard")
		{
			result = BuildBlackboard();
		}
	}

	if(result != Results::Success)
		OutputErrorMessageWithFileInfo(m_path_source, "Failed to load %s ", m_path_source);

	return result;
}

eae6320::cResult eae6320::Assets::cBehaviorTreeBuilder::BuildBehaviorTree()
{
	auto result = eae6320::Results::Success;
	lua_State* luaState = nullptr;
	std::vector<uint16_t> links;

	result = eae6320::LuaHelper::OpenAsset(m_path_source, luaState);
	if (!result)
	{
		goto OnExit;
	}

	// get links
	{

		lua_pushstring(luaState, "Links");
		lua_gettable(luaState, -2);

		uint16_t linksCount = static_cast<uint16_t>(luaL_len(luaState, -1));

		for (uint16_t i = 1; i <= linksCount; i++)
		{
			lua_pushinteger(luaState, i);
			lua_gettable(luaState, -2);
			int link[2];

			result = eae6320::LuaHelper::LoadTableArray_integer(-1, 2, link, luaState);
			if (!result)
				goto  OnExit;

			links.push_back(static_cast<uint16_t>(link[0]));
			links.push_back(static_cast<uint16_t>(link[1]));

			lua_pop(luaState, 1);
		}
		lua_pop(luaState, 1);
	}

	// write links to binary file
	{
		std::ofstream out(m_path_target, std::iostream::binary);

		if (links.size() > 0)
		{
			out.write(reinterpret_cast<char*>(links.data()), sizeof(links[0]) * links.size());
		}


		out.close();
	}

OnExit:
	if (result != eae6320::Results::Success)
	{
		OutputErrorMessageWithFileInfo(m_path_source, "Failed to load %s ", m_path_source);
	}
	LuaHelper::CloseAsset(luaState);

	return result;
}

namespace
{
	template<class T>
	void ReadName(lua_State* ipLuaState, std::vector<eae6320::AI::sBlackboardSelector<T>>& outSelectors, std::string name)
	{
		// get type
		lua_pushstring(ipLuaState, name.c_str());
		lua_gettable(ipLuaState, -2);

		if (!lua_isnil(ipLuaState, -1))
		{
			uint16_t count = static_cast<uint16_t>(luaL_len(ipLuaState, -1));
			for (uint16_t i = 1; i <= count; i++)
			{
				lua_pushinteger(ipLuaState, i);
				lua_gettable(ipLuaState, -2);

				// get name
				std::string name = lua_tostring(ipLuaState, -1);
				lua_pop(ipLuaState, 1);

				outSelectors.push_back(eae6320::AI::sBlackboardSelector<T>(name));
			}
		}
		lua_pop(ipLuaState, 1);
	}
}

eae6320::cResult eae6320::Assets::cBehaviorTreeBuilder::BuildBlackboard()
{
	auto result = eae6320::Results::Success;
	lua_State* luaState = nullptr;
	std::vector<eae6320::AI::sBlackboardSelector<bool>> boolSelectors;
	std::vector<eae6320::AI::sBlackboardSelector<float>> floatSelectors;
	std::vector<eae6320::AI::sBlackboardSelector<int>> intSelectors;
	std::vector<eae6320::AI::sBlackboardSelector<Math::sVector>> vectorSelectors;
	std::vector<eae6320::AI::sBlackboardSelector<uintptr_t>> pointerSelectors;

	result = eae6320::LuaHelper::OpenAsset(m_path_source, luaState);
	if (!result)
	{
		goto OnExit;
	}

	// get blackboard variable
	{
		ReadName(luaState, boolSelectors, "bool");
		ReadName(luaState, floatSelectors, "float");
		ReadName(luaState, intSelectors, "int");
		ReadName(luaState, vectorSelectors, "vector");
		ReadName(luaState, pointerSelectors, "pointer");
	}

	// write variables to binary
	{
		std::ofstream out(m_path_target, std::iostream::binary);

		// bool
		uint16_t size = static_cast<uint16_t>(boolSelectors.size());
		out.write(reinterpret_cast<char*>(&size), sizeof(size));
		for (int i = 0; i < size; i++)
		{
			std::string name = boolSelectors[i].mName;
			uint8_t length = static_cast<uint8_t>(name.length() + 1);
			out.write(reinterpret_cast<char*>(&length), sizeof(length));
			out.write(name.c_str(), name.length() + 1);
		}

		// int
		size = static_cast<uint16_t>(intSelectors.size());
		out.write(reinterpret_cast<char*>(&size), sizeof(size));
		for (int i = 0; i < size; i++)
		{
			std::string name = intSelectors[i].mName;
			uint8_t length = static_cast<uint8_t>(name.length() + 1);
			out.write(reinterpret_cast<char*>(&length), sizeof(length));
			out.write(name.c_str(), name.length() + 1);
		}

		// float
		size = static_cast<uint16_t>(floatSelectors.size());
		out.write(reinterpret_cast<char*>(&size), sizeof(size));
		for (int i = 0; i < size; i++)
		{
			std::string name = floatSelectors[i].mName;
			uint8_t length = static_cast<uint8_t>(name.length() + 1);
			out.write(reinterpret_cast<char*>(&length), sizeof(length));
			out.write(name.c_str(), name.length() + 1);
		}

		// vector
		size = static_cast<uint16_t>(vectorSelectors.size());
		out.write(reinterpret_cast<char*>(&size), sizeof(size));
		for (int i = 0; i < size; i++)
		{
			std::string name = vectorSelectors[i].mName;
			uint8_t length = static_cast<uint8_t>(name.length() + 1);
			out.write(reinterpret_cast<char*>(&length), sizeof(length));
			out.write(name.c_str(), name.length() + 1);
		}

		// pointer
		size = static_cast<uint16_t>(pointerSelectors.size());
		out.write(reinterpret_cast<char*>(&size), sizeof(size));
		for (int i = 0; i < size; i++)
		{
			std::string name = pointerSelectors[i].mName;
			uint8_t length = static_cast<uint8_t>(name.length() + 1);
			out.write(reinterpret_cast<char*>(&length), sizeof(length));
			out.write(name.c_str(), name.length() + 1);
		}

		out.close();
	}

OnExit:
	if (result != eae6320::Results::Success)
	{
		OutputErrorMessageWithFileInfo(m_path_source, "Failed to load %s ", m_path_source);
	}
	LuaHelper::CloseAsset(luaState);

	return result;
}
