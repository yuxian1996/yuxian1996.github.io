#pragma once

#include "../cBehaviorTree_Task.h"
#include "../cBlackboard.h"

#include <Engine/Framework/cGameObject.h>
#include <Engine/Math/sVector.h>

namespace eae6320
{
	namespace AI
	{
		class cTask_Wander : public cBehaviorTree_Task
		{
		public:
			cTask_Wander(const sBlackboardSelector<Math::sVector>& inSelector)
				: mVelocitySelector(inSelector) {};
			virtual ~cTask_Wander() override  = default;

			void ExcuteTask() const override
			{
				auto blackboard = mpTree->GetBlackboard();
				if (blackboard != nullptr)
				{
					mpTree->GetOwner()->GetRigidBodyState().velocity = blackboard->GetValue(mVelocitySelector);
				}
			}

		private:
			sBlackboardSelector<Math::sVector> mVelocitySelector;

		};
	}
}