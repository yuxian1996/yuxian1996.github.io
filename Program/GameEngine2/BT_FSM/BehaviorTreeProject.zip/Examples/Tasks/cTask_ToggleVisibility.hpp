#pragma once

#include "../cBehaviorTree_Task.h"

#include <Engine/Framework/cRenderableObject.h>

namespace eae6320
{
	namespace AI
	{
		class cTask_ToggleVisibility : public cBehaviorTree_Task
		{
			virtual void ExcuteTask() const override
			{
				Framework::cRenderableObject* owner = dynamic_cast<Framework::cRenderableObject*>(mpTree->GetOwner());
				if (owner != nullptr )
				{
					owner->bIsVisiable = !owner->bIsVisiable;
				}
			}
		};
	}
}