#pragma once

#include "../cBehaviorTree_Task.h"
#include <Engine/Framework/cGameObject.h>

namespace eae6320
{
	namespace Framework
	{
		class cGameObject;
	}

	namespace AI
	{
		class cTask_MoveToGameObject : public cBehaviorTree_Task
		{
		public:
			cTask_MoveToGameObject(Framework::cGameObject* ipGameObject) : cBehaviorTree_Task(), mpGameObject(ipGameObject){}
			virtual ~cTask_MoveToGameObject() {};
			virtual void ExcuteTask() const override
			{
				auto& owner = mpTree->GetOwner()->GetRigidBodyState();
				Math::sVector vector = mpGameObject->GetRigidBodyState().position - owner.position;
				if(vector != Math::sVector(0,0,0))
				{
					owner.velocity = vector.GetNormalized() * 1;
				}
				else
				{
					owner.velocity = Math::sVector(0, 0, 0);
				}
			};

		private:
			Framework::cGameObject* mpGameObject;

		};
	}
}