#pragma once

#include "../cBehaviorTree_Decorator.h"
#include <Engine/Framework/cGameObject.h>
#include <Engine/Math/sVector.h>

namespace  eae6320
{
	namespace AI
	{
		class cDecorator_GameObjectInSight : public cBehaviorTree_Decorator
		{
		public:
			cDecorator_GameObjectInSight(Framework::cGameObject* ipGameObject, float inDistance ) : mpGameObject(ipGameObject), mDistance(inDistance) {}
			virtual  ~cDecorator_GameObjectInSight()  = default;

			bool Check() const override
			{
				return (mpNode->GetTree()->GetOwner()->GetRigidBodyState().position - mpGameObject->GetRigidBodyState().position).
					GetLength() <= mDistance;
			}

		private:
			Framework::cGameObject* mpGameObject;
			float mDistance;
		};
	}
}