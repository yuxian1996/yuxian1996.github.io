--[[
	This file lists every asset that must be built by the AssetBuildSystem
]]

return
{
	shaders =
	{
		{ path = "Shaders/Vertex/vertexInputLayout.shader", arguments = { "vertex" } },
	},

	meshes = 
	{
		{ path = "Meshes/Triangle.mesh"},
		{ path = "Meshes/Plane.mesh"},
		{ path = "Meshes/Sphere.mesh"},
		{ path = "Meshes/Object.mesh"},
		{ path = "Meshes/Jerrycan.mesh"}
	},

	effects = 
	{
		{path = "Effects/standard.effect"}
	},

	behaviorTrees = 
	{
		{path = "BehaviorTrees/ExampleBT.bt", arguments = {"BehaviorTree"}},
		{path = "BehaviorTrees/ExampleBlackboard.bb", arguments = {"Blackboard"}}
	}
}
