// Includes
//=========

#include "cMyGame.h"
#include "Engine/Logging/Logging.h"

#include <Engine/Asserts/Asserts.h>
#include <Engine/UserInput/UserInput.h>
#include <Engine/Graphics/Graphics.h>
#include <Engine/Graphics/VertexFormats.h>
#include <Engine/Graphics/cEffect.h>
#include <Engine/Graphics/cMesh.h>
#include <Engine/Graphics/cModel.h>
#include <Engine/Framework//cGameObject.h>
#include <Engine/Framework/cCamera.h>
#include <Engine/Framework/cRenderableObject.h>
#include <Engine/Physics/sRigidBodyState.h>

// Plugins
#include <Plugins/BehaviorTree/cBehaviorTree.h>
#include <Plugins/BehaviorTree/cBehaviorTree_Selector.h>
#include <Plugins/BehaviorTree/Tasks/cTask_MoveToGameObject.hpp>
#include <Plugins/BehaviorTree/Decorators/cDecorator_GameObjectInSight.hpp>
#include <Plugins/BehaviorTree/cBehaviorTree_Sequence.h>
#include <Plugins/BehaviorTree/cBlackboard.h>
#include <Plugins/BehaviorTree/Services/cService_WanderVelocity.hpp>
#include <Plugins/BehaviorTree/Tasks/cTask_Wander.hpp>
#include <Plugins/BehaviorTree/Tasks/cTask_ToggleVisibility.hpp>
#include <vector>

#define INITIALIZE_FROM_FILE 1

// Inherited Implementation
//=========================

void eae6320::cMyGame::SubmitDataToBeRendered(const float i_elapsedSecondCount_systemTime, const float i_elapsedSecondCount_sinceLastSimulationUpdate)
{
	// submit background color to graphics
	Graphics::SubmitBackgroundColor(mBackgroundColor[0], mBackgroundColor[1], mBackgroundColor[2]);

	// submit game object to graphics
	for (size_t i = 0; i < mGameObjects.size(); i++)
		Graphics::SubmitRenderableObject(mGameObjects[i], i_elapsedSecondCount_sinceLastSimulationUpdate);

	// submit camera to graphics
	Graphics::SubmitCamera(mpCamera, i_elapsedSecondCount_sinceLastSimulationUpdate);
}

void eae6320::cMyGame::UpdateBasedOnTime(const float i_elapsedSecondCount_sinceLastUpdate)
{
	//mGameObjects[2]->GetRigidBodyState().velocity = Math::sVector(0, 0, 0);

	//mpBehaviorTree->Execute(i_elapsedSecondCount_sinceLastUpdate);


	/*mpStateMachine->Run();
	static int count = 100;
	if (count >= 0)
		count--;
	else
	{
		mpStateMachine->GetBlackboard()->SetValue(AI::sBlackboardSelector<bool>("Pass"), true);
	}*/
}


// Run
//----

void eae6320::cMyGame::UpdateBasedOnInput()
{
	// Is the user pressing the ESC key?
	if ( UserInput::IsKeyPressed( UserInput::KeyCodes::Escape ) )
	{
		// Exit the application
		const auto result = Exit( EXIT_SUCCESS );
		EAE6320_ASSERT( result );
	}

	// Is the user pressing SPACE?
	if (UserInput::IsKeyPressed(UserInput::KeyCodes::Space))
	{
		// Make game slow
		SetSimulationRate(0.3f);
	}
	else
	{
		// Resume
		SetSimulationRate(1);
	}

}

void eae6320::cMyGame::UpdateSimulationBasedOnInput()
{
	if (UserInput::IsKeyPressed(UserInput::KeyCodes::Up) || UserInput::IsKeyPressed(UserInput::KeyCodes::Left) ||
		UserInput::IsKeyPressed(UserInput::KeyCodes::Down) || UserInput::IsKeyPressed(UserInput::KeyCodes::Right))
	{
		// move camera
		if (UserInput::IsKeyPressed(UserInput::KeyCodes::Up))
		{
			mpCamera->GetRigidBodyState().velocity = Math::sVector(0, 0, -5);
		}

		if (UserInput::IsKeyPressed(UserInput::KeyCodes::Left))
		{
			mpCamera->GetRigidBodyState().velocity = Math::sVector(-5, 0, 0);
		}

		if (UserInput::IsKeyPressed(UserInput::KeyCodes::Down))
		{
			mpCamera->GetRigidBodyState().velocity = Math::sVector(0, 0, 5);
		}

		if (UserInput::IsKeyPressed(UserInput::KeyCodes::Right))
		{
			mpCamera->GetRigidBodyState().velocity = Math::sVector(5, 0, 0);
		}
	}
	else
		mpCamera->GetRigidBodyState().velocity = Math::sVector();

	// move game object
	if (UserInput::IsKeyPressed('W') || UserInput::IsKeyPressed('A') ||
		UserInput::IsKeyPressed('S') || UserInput::IsKeyPressed('D'))
	{
		if (UserInput::IsKeyPressed('W'))
		{
			if (UserInput::IsKeyPressed(UserInput::KeyCodes::Control))
				mGameObjects[0]->GetRigidBodyState().velocity = Math::sVector(0, 5, 0);
			else
				mGameObjects[1]->GetRigidBodyState().velocity = Math::sVector(0, 5, 0);
		}

		if (UserInput::IsKeyPressed('A'))
		{
			if (UserInput::IsKeyPressed(UserInput::KeyCodes::Control))
				mGameObjects[0]->GetRigidBodyState().velocity = Math::sVector(-5, 0, 0);
			else
				mGameObjects[1]->GetRigidBodyState().velocity = Math::sVector(-5, 0, 0);
		}

		if (UserInput::IsKeyPressed('S'))
		{
			if (UserInput::IsKeyPressed(UserInput::KeyCodes::Control))
				mGameObjects[0]->GetRigidBodyState().velocity = Math::sVector(0, -5, 0);
			else
				mGameObjects[1]->GetRigidBodyState().velocity = Math::sVector(0, -5, 0);
		}

		if (UserInput::IsKeyPressed('D'))
		{
			if (UserInput::IsKeyPressed(UserInput::KeyCodes::Control))
				mGameObjects[0]->GetRigidBodyState().velocity = Math::sVector(5, 0, 0);
			else
				mGameObjects[1]->GetRigidBodyState().velocity = Math::sVector(5, 0, 0);
		}

	}
	else
	{
		mGameObjects[0]->GetRigidBodyState().velocity = Math::sVector();
		mGameObjects[1]->GetRigidBodyState().velocity = Math::sVector();
	}

	if (UserInput::IsKeyPressed('Q') || UserInput::IsKeyPressed('E'))
	{
		if (UserInput::IsKeyPressed('Q'))
		{
			mpCamera->GetRigidBodyState().angularSpeed = 2;
		}

		if (UserInput::IsKeyPressed('E'))
		{
			mpCamera->GetRigidBodyState().angularSpeed = -2;
		}
	}
	else
	{
		mpCamera->GetRigidBodyState().angularSpeed = 0;
	}

}

void eae6320::cMyGame::UpdateSimulationBasedOnTime(const float i_elapsedSecondCount_sinceLastUpdate)
{
	static bool isHide = false;
	static float time = 0;

	// blink triangle
	if (time > 0.1f)
	{
		isHide = !isHide;
		time = 0;
	}
	else
		time += i_elapsedSecondCount_sinceLastUpdate;

	// update background color based on time
	mBackgroundColor[0] = sin(static_cast<float>(GetElapsedSecoundCount_simulationTime()));
	mBackgroundColor[1] = cos(static_cast<float>(GetElapsedSecoundCount_simulationTime()));
	mBackgroundColor[2] = cos(static_cast<float>(GetElapsedSecoundCount_simulationTime()));
	
	for (size_t i = 0; i < mGameObjects.size(); ++i)
		mGameObjects[i]->Update(i_elapsedSecondCount_sinceLastUpdate);

	mpCamera->Update(i_elapsedSecondCount_sinceLastUpdate);

	mpBehaviorTree->Execute(i_elapsedSecondCount_sinceLastUpdate);

}


// Initialization / Clean Up
//--------------------------

eae6320::cResult eae6320::cMyGame::Initialize()
{
	std::vector<eae6320::Graphics::VertexFormats::sMesh> mesh1 = { { -1.0f,1.0f, 0.0f },{ 1.0f, 1.0f, 0.0f },{ -1.0f, -1.0f, 0.0f },{ 1.0f, -1.0f, 0.0f } };
	std::vector<eae6320::Graphics::VertexFormats::sMesh> mesh2 = { { 0.0f, 0.0f, -5.0f },{ 1.0f, 0.0f, -5.0f },{ 0.0f, 1.0f, -5.0f } };
	std::vector<uint16_t> indices1 = { 0, 2, 1, 1, 2, 3 };
	std::vector<uint16_t> indices2 = { 0,1,2 };

	using cEffect = eae6320::Graphics::cEffect;
	using cMesh = eae6320::Graphics::cMesh;
	using cModel = eae6320::Graphics::cModel;
	using cGameObject = eae6320::Framework::cGameObject;
	using cCamera = eae6320::Framework::cCamera;
	using cRenderableObject = eae6320::Framework::cRenderableObject;
	using sRigidBodyState = eae6320::Physics::sRigidBodyState;

	Assets::cHandle<Graphics::cMesh> handle1, handle2, handle3;
	cMesh::Create("data/Meshes/Plane.msh", handle1);
	cMesh::Create("data/Meshes/Jerrycan.msh", handle2);
	cMesh::Create("data/Meshes/Sphere.msh", handle3);
	mMeshHandles.push_back(handle1);
	mMeshHandles.push_back(handle2);
	mMeshHandles.push_back(handle3);

	// Initialize effects
	cEffect* pEffect1 = nullptr, *pEffect2 = nullptr;

	cEffect::Load("data/Effects/standard.eft", pEffect1);
	cEffect::Load("data/Effects/standard.eft", pEffect2);
	mEffects.push_back(pEffect1);
	mEffects.push_back(pEffect2);

	sRigidBodyState originalState;

	cRenderableObject* gameObject1 = new cRenderableObject(originalState, cMesh::sManager.Get(handle1), pEffect1);
	cRenderableObject* gameObject2 = new cRenderableObject(originalState, cMesh::sManager.Get(handle2), pEffect2);
	cRenderableObject* gameObject3 = new cRenderableObject(originalState, cMesh::sManager.Get(handle3), pEffect2);
	mGameObjects.push_back(gameObject1);
	mGameObjects.push_back(gameObject2);
	mGameObjects.push_back(gameObject3);

	sRigidBodyState cameraBody(Math::sVector(0, 0, 10), Math::sVector(), Math::sVector(), Math::cQuaternion());
	mpCamera = new cCamera(cameraBody, 45, 1, 0.1f, 100);
	mpCamera->GetRigidBodyState().angularVelocity_axis_local = Math::sVector(1, 0, 0);

	// Initialize blackboard
	AI::cBlackboard* blackboard = nullptr;
	if (INITIALIZE_FROM_FILE)
	{
		AI::cBlackboard::Load("data/BehaviorTrees/ExampleBlackboard.bb", blackboard);
	}
	else
	{
		blackboard = new AI::cBlackboard();
		blackboard->AddKey(AI::sBlackboardSelector<Math::sVector>("WanderVelocity"));
	}


	// Initialize behavior tree
	mpBehaviorTree = new AI::cBehaviorTree(gameObject3, blackboard);

	AI::cTask_MoveToGameObject* task = new AI::cTask_MoveToGameObject(gameObject2);
	AI::cDecorator_GameObjectInSight* decorator = new AI::cDecorator_GameObjectInSight(gameObject2, 10);
	task->AddDecorator(decorator);

	AI::cBehaviorTree_Selector* selector = new AI::cBehaviorTree_Selector();
	AI::cBehaviorTree_Sequence* sequence = new AI::cBehaviorTree_Sequence();

	// wander
	AI::sBlackboardSelector<Math::sVector> bbSelector("WanderVelocity");
	AI::cTask_Wander* wander = new AI::cTask_Wander(bbSelector);
	AI::cBehaviorTree_Service* service = new AI::cService_WanderVelocity(4.0f, bbSelector);
	wander->AddService(service);

	AI::cTask_ToggleVisibility* toggleVisibility = new AI::cTask_ToggleVisibility();

	mpBehaviorTree->SetRoot(selector);

	std::vector<AI::cBehaviorTreeNode*> nodes;
	nodes.push_back(selector);
	nodes.push_back(task);
	nodes.push_back(sequence);
	nodes.push_back(wander);
	nodes.push_back(toggleVisibility);


	if (INITIALIZE_FROM_FILE)
	{
		AI::cBehaviorTree::LoadLinks(nodes, "data/BehaviorTrees/ExampleBT.bt");
	}
	else
	{
		// link behavior tree nodes
		std::vector<std::pair<uint16_t, uint16_t>> links;
		links.push_back(std::make_pair(0, 1));
		links.push_back(std::make_pair(0, 2));
		links.push_back(std::make_pair(2, 3));
		links.push_back(std::make_pair(2, 4));

		AI::cBehaviorTree::Link(nodes, links);
	}

	return Results::Success;
}

eae6320::cResult eae6320::cMyGame::CleanUp()
{
	for (unsigned int i = 0; i < mGameObjects.size(); ++i)
		delete mGameObjects[i];

	for (unsigned int i = 0; i < mMeshHandles.size(); ++i)
		Graphics::cMesh::sManager.Release(mMeshHandles[i]);
	for (unsigned int i = 0; i < mEffects.size(); ++i)
		mEffects[i]->DecrementReferenceCount();

	delete mpCamera;

	mpBehaviorTree->Cleanup();

	return Results::Success;
}
