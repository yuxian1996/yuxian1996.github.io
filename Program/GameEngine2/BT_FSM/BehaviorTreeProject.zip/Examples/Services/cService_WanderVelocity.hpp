#pragma once

#include "../cBehaviorTree_Service.h"
#include "../cBlackboard.h"

#include <Engine/Math/sVector.h>
#include <Engine/Logging/Logging.h>
#include <random>

namespace eae6320
{
	namespace AI
	{
		class cService_WanderVelocity : public cBehaviorTree_Service
		{
		public:
			cService_WanderVelocity(float inInterval = 10.0f, const sBlackboardSelector<Math::sVector>& inSelector = sBlackboardSelector<Math::sVector>()) : 
				cBehaviorTree_Service(inInterval) , mVelocitySelector(inSelector)
			{};

			virtual ~cService_WanderVelocity() override {};
			void Execute() override
			{
				// change velocity
				auto blackboard = mpNode->GetTree()->GetBlackboard();
				if (blackboard != nullptr)
				{
					std::uniform_real_distribution<float> value(-1.0f, 1.0f);
					Math::sVector vector(value(generator), value(generator), 0);

					blackboard->SetValue(mVelocitySelector, vector);
				}
			}

		private:
			sBlackboardSelector<Math::sVector> mVelocitySelector;
			std::default_random_engine generator;
		};
	}
}