Controls
W/A/S/D to move player unit. 
SPACE to dash.
ESCAPE to exit game.
