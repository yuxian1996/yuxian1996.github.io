Press W/A/S/D to move the polyhedron.
Hold Control and press W/A/S/D to move the plane.
Press Up/Down/Left/Right Arrow to move camera.