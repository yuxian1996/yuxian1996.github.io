Control:

Press and hold SPACE to make color animation slow. Release to return to normal speed.
Press and hold F1 to hide the top triangle, press and hold F2 to change the color of the top triangle to pure white.